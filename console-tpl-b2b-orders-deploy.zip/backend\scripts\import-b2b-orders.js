/**
 * B端销售订单 - Excel 导入脚本
 *
 * 数据源：金蝶「销售订单」月报导出（一行 = 一个订单行，同一单据编号多行）
 * 用途：
 *   1) 按「单据编号」聚合成订单头 + 明细行，幂等写入本地库 b2b_orders / b2b_order_items
 *   2) 同时生成可直接上传宝塔导入 console-backend 的 .sql 文件
 *
 * 用法：
 *   node scripts/import-b2b-orders.js "D:\TraeWork Data\B端订单\10月B端月报销售订单数据.xlsx"
 *   node scripts/import-b2b-orders.js "xxx.xlsx" --sql-out "D:\xxx\b2b_orders.sql"
 *   node scripts/import-b2b-orders.js "xxx.xlsx" --no-sql     # 只入本地库
 */
const fs = require('fs');
const path = require('path');
const XLSX = require('xlsx');
const db = require('../config/db');

const DEFAULT_XLSX = 'D:\\TraeWork Data\\B端订单\\10月B端月报销售订单数据.xlsx';
const DEFAULT_SQL_DIR = 'D:\\myCode\\huiyi\\DataSync\\订单SQL导入';
const MIGRATION_SQL = path.join(__dirname, '..', 'db', 'migrations', '2026-11-10_create_b2b_orders.sql');

// ---------- 参数解析 ----------
const argv = process.argv.slice(2);
const inputFile = argv.find((a) => !a.startsWith('--')) || DEFAULT_XLSX;
const sqlOutIdx = argv.indexOf('--sql-out');
const sqlOutArg = sqlOutIdx >= 0 ? argv[sqlOutIdx + 1] : null;
const noSql = argv.includes('--no-sql');

// ---------- 工具函数 ----------
const text = (v) => {
  if (v === null || v === undefined) return null;
  const s = String(v).trim();
  return s === '' ? null : s;
};

const num = (v) => {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(String(v).replace(/,/g, ''));
  return Number.isFinite(n) ? n : null;
};

const round2 = (n) => Math.round((n + Number.EPSILON) * 100) / 100;

function excelDate(v) {
  if (typeof v === 'number' && v > 20000) {
    const d = new Date(Date.UTC(1899, 11, 30) + Math.round(v) * 86400000);
    return d.toISOString().slice(0, 10);
  }
  const s = text(v);
  if (!s) return null;
  const m = s.match(/^(\d{4})[-./](\d{1,2})[-./](\d{1,2})/);
  return m ? `${m[1]}-${m[2].padStart(2, '0')}-${m[3].padStart(2, '0')}` : null;
}

function excelDateTime(v) {
  const s = text(v);
  if (!s) return null;
  const m = s.match(/^(\d{4})[-./](\d{1,2})[-./](\d{1,2})[ T](\d{1,2}):(\d{1,2}):(\d{1,2})/);
  if (!m) return null;
  const p = (x) => String(x).padStart(2, '0');
  return `${m[1]}-${p(m[2])}-${p(m[3])} ${p(m[4])}:${p(m[5])}:${p(m[6])}`;
}

// ---------- 解析 Excel ----------
function parseWorkbook(file) {
  if (!fs.existsSync(file)) throw new Error(`Excel 文件不存在：${file}`);
  const wb = XLSX.readFile(file);
  const ws = wb.Sheets[wb.SheetNames[0]];
  // 第 1 行为大标题，第 2 行为表头
  const rows = XLSX.utils.sheet_to_json(ws, { defval: '', raw: true, range: 1 });

  const groups = new Map();
  for (const r of rows) {
    const orderNo = text(r['单据编号行']) || text(r['单据编号']);
    if (!orderNo) continue; // 跳过表尾空行

    if (!groups.has(orderNo)) groups.set(orderNo, []);
    groups.get(orderNo).push(r);
  }

  const orders = [];
  for (const [orderNo, lines] of groups) {
    const first = lines[0];
    const pick = (key) => {
      for (const l of lines) {
        const v = text(l[key]);
        if (v) return v;
      }
      return null;
    };

    const items = lines
      .map((l) => ({
        order_no: orderNo,
        line_no: text(l['单据行号']) || '10',
        material_no: text(l['物料编号']),
        material_name: text(l['物料名称']),
        spec: text(l['规格型号']),
        unit_price: num(l['销售单价']),
        quantity: num(l['销售数量']) ?? 0,
        pre_amount: num(l['预收金额(核算币种)']) ?? 0,
        local_amount: num(l['金额（本位币）']) ?? 0,
        untaxed_total: num(l['未税总金额(交易币种)']) ?? 0,
        untaxed_line_amount: num(l['销售订单行.未税金额(交易币种)']) ?? 0,
        sales_fx_amount: num(l['销售总额(核算币种)']) ?? 0,
        sales_local_amount: num(l['销售总额(本币)']) ?? 0,
        tax_amount: num(l['价税合计(核算币种)']) ?? 0,
        purchase_price: num(l['采购单价']),
        purchase_total: num(l['采购总金额']) ?? 0,
        purchase_order_total: num(l['采购单总额']) ?? 0,
        return_amount: num(l['退货金额']) ?? 0,
        gross_profit: num(l['单品毛利润']) ?? 0,
        gross_profit_rate: num(l['单品毛利润率']),
        remark: text(l['备注'])
      }))
      .sort((a, b) => Number(a.line_no) - Number(b.line_no));

    const sum = (key) => round2(items.reduce((acc, it) => acc + (Number(it[key]) || 0), 0));

    orders.push({
      order_no: orderNo,
      biz_date: excelDate(first['业务日期']),
      doc_type: pick('单据类型行'),
      supplier: pick('供应商'),
      status: pick('状态'),
      department: pick('部门'),
      sales_person: pick('销售业务员'),
      clerk: pick('业务员'),
      purchase_order_no: pick('采购订单号'),
      customer_type: pick('新老客户'),
      created_time: excelDateTime(first['创建时间']),
      customer: pick('客户'),
      delivery_method: pick('交货方式'),
      address: pick('收货地址信息'),
      country: pick('客户国家'),
      province: pick('客户省份/地区'),
      city: pick('客户城市'),
      customer_source: pick('客户来源'),
      ship_status: pick('发货情况'),
      customer_email: pick('客户邮箱'),
      line_count: items.length,
      item_count: sum('quantity'),
      total_amount: sum('tax_amount'),
      untaxed_amount: sum('untaxed_total'),
      purchase_amount: sum('purchase_total'),
      refund_amount: sum('return_amount'),
      gross_profit: sum('gross_profit'),
      currency: 'CNY',
      remark: items.map((i) => i.remark).find(Boolean) || null,
      items
    });
  }

  orders.sort((a, b) => String(b.biz_date).localeCompare(String(a.biz_date)) || b.order_no.localeCompare(a.order_no));
  return orders;
}

// ---------- 写入本地库 ----------
const ORDER_FIELDS = [
  'order_no', 'biz_date', 'doc_type', 'supplier', 'status', 'department', 'sales_person',
  'clerk', 'purchase_order_no', 'customer_type', 'created_time', 'customer', 'delivery_method',
  'address', 'country', 'province', 'city', 'customer_source', 'ship_status', 'customer_email',
  'line_count', 'item_count', 'total_amount', 'untaxed_amount', 'purchase_amount',
  'refund_amount', 'gross_profit', 'currency', 'remark'
];

const ITEM_FIELDS = [
  'order_no', 'line_no', 'material_no', 'material_name', 'spec', 'unit_price', 'quantity',
  'pre_amount', 'local_amount', 'untaxed_total', 'untaxed_line_amount', 'sales_fx_amount',
  'sales_local_amount', 'tax_amount', 'purchase_price', 'purchase_total', 'purchase_order_total',
  'return_amount', 'gross_profit', 'gross_profit_rate', 'remark'
];

async function importToDb(orders) {
  const conn = await db.getConnection();
  let itemTotal = 0;
  try {
    await conn.beginTransaction();
    for (const o of orders) {
      const orderValues = ORDER_FIELDS.map((f) => o[f]);
      const updates = ORDER_FIELDS
        .filter((f) => f !== 'order_no')
        .map((f) => `\`${f}\` = VALUES(\`${f}\`)`)
        .join(', ');
      await conn.query(
        `INSERT INTO b2b_orders (${ORDER_FIELDS.map((f) => `\`${f}\``).join(', ')}) VALUES (?) ON DUPLICATE KEY UPDATE ${updates}`,
        [orderValues]
      );
      const [[row]] = await conn.query('SELECT id FROM b2b_orders WHERE order_no = ?', [o.order_no]);
      await conn.query('DELETE FROM b2b_order_items WHERE order_no = ?', [o.order_no]);
      const itemRows = o.items.map((it) => [row.id, ...ITEM_FIELDS.map((f) => it[f])]);
      if (itemRows.length) {
        await conn.query(
          `INSERT INTO b2b_order_items (order_id, ${ITEM_FIELDS.map((f) => `\`${f}\``).join(', ')}) VALUES ?`,
          [itemRows]
        );
        itemTotal += itemRows.length;
      }
    }
    await conn.commit();
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
  return itemTotal;
}

// ---------- 生成线上导入 SQL ----------
const sqlEscape = (v) => {
  if (v === null || v === undefined) return 'NULL';
  if (typeof v === 'number') return String(v);
  return `'${String(v).replace(/\\/g, '\\\\').replace(/'/g, "\\'").replace(/\n/g, '\\n').replace(/\r/g, '')}'`;
};

function buildSql(orders) {
  const migration = fs.readFileSync(MIGRATION_SQL, 'utf8');
  const lines = [
    '-- B端销售订单导入（console-backend）',
    `-- 生成时间: ${new Date().toISOString()}`,
    '-- 说明: 仅创建/写入 b2b_orders、b2b_order_items 两张表，不影响 C 端 orders 及其他业务表',
    '',
    'SET NAMES utf8mb4;',
    'SET FOREIGN_KEY_CHECKS = 0;',
    '',
    migration.trim(),
    ''
  ];

  for (const o of orders) {
    lines.push(
      `REPLACE INTO \`b2b_orders\` (${ORDER_FIELDS.map((f) => `\`${f}\``).join(', ')}) VALUES (${ORDER_FIELDS.map((f) => sqlEscape(o[f])).join(', ')});`
    );
  }

  lines.push('');

  for (const o of orders) {
    for (const it of o.items) {
      const values = ITEM_FIELDS.map((f) => sqlEscape(it[f]));
      const orderIdExpr = `(SELECT id FROM b2b_orders WHERE order_no = ${sqlEscape(o.order_no)} LIMIT 1)`;
      lines.push(
        `REPLACE INTO \`b2b_order_items\` (\`order_id\`, ${ITEM_FIELDS.map((f) => `\`${f}\``).join(', ')}) VALUES (${[orderIdExpr, ...values].join(', ')});`
      );
    }
  }

  lines.push('', 'SET FOREIGN_KEY_CHECKS = 1;', '');
  return lines.join('\n');
}

// ---------- 主流程 ----------
(async () => {
  try {
    console.log(`📖 读取: ${inputFile}`);
    const orders = parseWorkbook(inputFile);
    const itemCount = orders.reduce((n, o) => n + o.items.length, 0);
    const totalAmount = round2(orders.reduce((n, o) => n + o.total_amount, 0));
    console.log(`✅ 解析完成: 订单 ${orders.length} 单 / 明细 ${itemCount} 行 / 价税合计 ${totalAmount}`);

    const insertedItems = await importToDb(orders);
    console.log(`✅ 已写入本地库: 订单 ${orders.length} 单 / 明细 ${insertedItems} 行`);

    if (!noSql) {
      const month = (orders.map((o) => o.biz_date).filter(Boolean).sort().pop() || '').slice(0, 7) || 'unknown';
      const outFile = sqlOutArg || path.join(DEFAULT_SQL_DIR, `b2b_orders_${month}.sql`);
      fs.mkdirSync(path.dirname(outFile), { recursive: true });
      fs.writeFileSync(outFile, buildSql(orders), 'utf8');
      console.log(`✅ 线上导入 SQL 已生成: ${outFile} (${(fs.statSync(outFile).size / 1024).toFixed(1)} KB)`);
    }

    process.exit(0);
  } catch (err) {
    console.error('❌ 导入失败:', err.message);
    process.exit(1);
  }
})();
